#include "mcc_generated_files/mcc.h"
#include "splunk.h"

/*
                         Main application
 */
void delay(void);
void light(int l7,int l6,int l5,int l4,int l3,int l2,int l1,unsigned int d);
void delay_ms(unsigned int milliseconds);

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    
    int button_pushed = 0;
    state_type state = SLEEP;
    int dotDelay = 6;
    int spaceDelay = 12; 
    

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    while (1)
    {
        // Add your application code
        if(button1_GetValue()==0) //check for button push
        {
            __delay_ms(1); //debounce
            while (button1_GetValue()==0) //holding down button
            {
                led1_SetHigh();
                led2_SetHigh();
                led3_SetHigh();
                led4_SetHigh();
                led5_SetHigh();
                led6_SetHigh();
                led7_SetHigh();
                button_pushed=1;
            }
            led1_SetLow();
            led2_SetLow();
            led3_SetLow();
            led4_SetLow();
            led5_SetLow();
            led6_SetLow();
            led7_SetLow();
        }
        
        if (button_pushed) // button pushed
		{
			switch (state)
      		{
				case SLEEP:
					state = ON;
					break;
        		case ON:
          			state = BLINK_SLOW;
          			break;
        		case BLINK_SLOW:
          			state = BLINK_FAST;
          			break;
                case BLINK_FAST:
          			state = RUN;
          			break;
        		case RUN:
					state = RANDOM;
					break;
				case RANDOM:
          			state = RAILROAD;
                    break;
                case RAILROAD:
          			state = TAE;
          			break;
                case TAE:
                    state = SLEEP;
                    break;
      		}
			button_pushed = 0;
        }
        
        switch (state)
        {
         	case ON:			// turn on LEDs
				led1_SetHigh();
                led2_SetHigh();
                led3_SetHigh();
                led4_SetHigh();
                led5_SetHigh();
                led6_SetHigh();
                led7_SetHigh();
            	break;
          	case BLINK_SLOW:				// blink LEDs
                led1_Toggle();
                led2_Toggle();
                led3_Toggle();
                led4_Toggle();
                led5_Toggle();
                led6_Toggle();
                led7_Toggle();
                //__delay_ms(1000);
                delay_ms(1000);
                break;
            case BLINK_FAST:				// blink LEDs
            	led1_Toggle();
                led2_Toggle();
                led3_Toggle();
                led4_Toggle();
                led5_Toggle();
                led6_Toggle();
                led7_Toggle();
                //__delay_ms(100);
                delay_ms(100);
            	break;
          	case RUN:				// alternate LEDs
            	led1_SetHigh();
                led2_SetLow();
                led3_SetLow();
                led4_SetLow();
                led5_SetLow();
                led6_SetLow();
                led7_SetLow();
                //__delay_ms(200);
                delay_ms(200);
                led1_SetLow();
                led2_SetHigh();
                led3_SetLow();
                led4_SetLow();
                led5_SetLow();
                led6_SetLow();
                led7_SetLow();
                //__delay_ms(200);
                delay_ms(200);
                led1_SetLow();
                led2_SetLow();
                led3_SetHigh();
                led4_SetLow();
                led5_SetLow();
                led6_SetLow();
                led7_SetLow();
                //__delay_ms(200);
                delay_ms(200);
                led1_SetLow();
                led2_SetLow();
                led3_SetLow();
                led4_SetHigh();
                led5_SetLow();
                led6_SetLow();
                led7_SetLow();
                //__delay_ms(200);
                delay_ms(200);
                led1_SetLow();
                led2_SetLow();
                led3_SetLow();
                led4_SetLow();
                led5_SetHigh();
                led6_SetLow();
                led7_SetLow();
                //__delay_ms(200);
                delay_ms(200);
                led1_SetLow();
                led2_SetLow();
                led3_SetLow();
                led4_SetLow();
                led5_SetLow();
                led6_SetHigh();
                led7_SetLow();
                //__delay_ms(200);
                delay_ms(200);
                led1_SetLow();
                led2_SetLow();
                led3_SetLow();
                led4_SetLow();
                led5_SetLow();
                led6_SetLow();
                led7_SetHigh();
                //__delay_ms(200);
                delay_ms(200);
            	break;
		  case RANDOM:			
              led1_Toggle();
              delay();
              led2_Toggle();
              delay();
              led3_Toggle();
              delay();
              led4_Toggle();
              delay();
              led5_Toggle();
              delay();
              led6_Toggle();
              delay();
              led7_Toggle();
              delay();
              break;
          case RAILROAD:			
              led1_SetHigh();
              led2_SetLow();
              led3_SetHigh();
              led4_SetLow();
              led5_SetHigh();
              led6_SetLow();
              led7_SetHigh();
              //__delay_ms(200);
              delay_ms(200);
              led1_SetLow();
              led2_SetHigh();
              led3_SetLow();
              led4_SetHigh();
              led5_SetLow();
              led6_SetHigh();
              led7_SetLow();
              //__delay_ms(200);
              delay_ms(200);
              break;  
          case TAE:
              light(1,0,0,0,0,0,0,10);
              //led7_SetHigh();
              //led6_SetLow();
              //led5_SetLow();
              //led4_SetLow();
              //led3_SetLow();
              //led2_SetLow();
              //led1_SetLow();
              __delay_ms(10);
              light(1,0,0,0,0,0,0,10);
              //led7_SetHigh();
              //led6_SetLow();
              //led5_SetLow();
              //led4_SetLow();
              //led3_SetLow();
              //led2_SetLow();
              //led1_SetLow();
              __delay_ms(10);
              light(1,1,1,1,1,1,1,10);
              //led7_SetHigh();
              //led6_SetHigh();
              //led5_SetHigh();
              //led4_SetHigh();
              //led3_SetHigh();
              //led2_SetHigh();
              //led1_SetHigh();
              __delay_ms(10);
              light(1,0,0,0,0,0,0,10);
              //led7_SetHigh();
              //led6_SetLow();
              //led5_SetLow();
              //led4_SetLow();
              //led3_SetLow();
              //led2_SetLow();
              //led1_SetLow();
              __delay_ms(10);
              light(1,0,0,0,0,0,0,10);
              //led7_SetHigh();
              //led6_SetLow();
              //led5_SetLow();
              //led4_SetLow();
              //led3_SetLow();
              //led2_SetLow();
              //led1_SetLow();
              __delay_ms(10);
              light(0,0,0,0,0,0,0,1000);
              //led7_SetLow();
              //led6_SetLow();
              //led5_SetLow();
              //led4_SetLow();
              //led3_SetLow();
              //led2_SetLow();
              //led1_SetLow();
              delay_ms(500);
              break;
          case SLEEP:
              led1_SetLow();
              led2_SetLow();
              led3_SetLow();
              led4_SetLow();
              led5_SetLow();
              led6_SetLow();
              led7_SetLow();
              break;
		  default:
				break; 
        }
        
    }//while
}//main

void delay()
    {   
        int i=0,j=0;
        int r=(rand() % (200 + 1 - 5)) + 5;
        for(i=0;i<r;i++){for(j=0;j<16;j++){}}
    }

void delay_ms(unsigned int milliseconds)
{
   while(milliseconds > 0)
   {
      milliseconds--;
       __delay_us(990);
   }
}

void light(int l7,int l6,int l5,int l4,int l3,int l2,int l1,unsigned int d)
{
    if(l7){
              led7_SetHigh();
    }
    else{
              led7_SetLow();
    }
    if(l6){
              led6_SetHigh();
    }
    else{
              led6_SetLow();
    }
    if(l5){
              led5_SetHigh();
    }
    else{
              led5_SetLow();
    }
    if(l4){
              led4_SetHigh();
    }
    else{
              led4_SetLow();
    }
    if(l3){
              led3_SetHigh();
    }
    else{
              led3_SetLow();
    }
    if(l2){
              led2_SetHigh();
    }
    else{
              led2_SetLow();
    }
    if(l1){
              led1_SetHigh();
    }
    else{
              led1_SetLow();
    }
    delay_ms(d);
}
/**
 End of File
*/